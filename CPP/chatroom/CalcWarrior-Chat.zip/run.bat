@echo off
chcp 65001 > nul
title CalcWarrior Chat

:: Get local IP for LAN access
for /f "tokens=2 delims=:" %%i in ('ipconfig ^| findstr /c:"IPv4" /c:"IP Address"') do (
    set IP=%%i
    goto :found
)
:found
set IP=%IP: =%

echo === CalcWarrior Chat Server ===
echo.
echo Starting...
echo.
echo Local:   http://localhost:8080
echo LAN:     http://%IP%:8080
echo.
echo Share LAN address with others on your network.
echo Close this window to stop the server.
echo.

:: Start server in background
start /b server.exe > nul 2>&1

:: Wait for server to start
timeout /t 2 /nobreak > nul

:: Open browser
start http://localhost:8080

:: Keep window alive with instructions
echo Press any key to stop the server...
pause > nul

:: Stop server
taskkill /f /im server.exe > nul 2>&1
